document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('contactForm');
    const formStatus = document.getElementById('form-status');

    form.addEventListener('submit', async function (event) {
        event.preventDefault();
        const formData = new FormData(form);

        const phoneNumber = formData.get('phone'); // supondo que o campo do telefone seja 'phone'
        const message = formData.get('message'); // supondo que o campo da mensagem seja 'message'

        const whatsappURL = `https://wa.me/${5543998009601}?text=${encodeURIComponent(message)}`;

        try {
            window.open(whatsappURL, '_blank'); // Abre o link do WhatsApp em uma nova aba
            form.reset();
            formStatus.innerHTML = 'Mensagem enviada com sucesso!';
            formStatus.style.color = 'green';
        } catch (error) {
            formStatus.innerHTML = 'Erro ao enviar mensagem. Por favor, tente novamente mais tarde.';
            formStatus.style.color = 'red';
        }
    });
});